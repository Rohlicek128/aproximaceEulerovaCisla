import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try {
            EulersNumber e = new EulersNumber();
            Scanner input = new Scanner(System.in);

            System.out.print("NUMBER OF DIGITS OF e: ");
            int decimals = input.nextInt();
            //System.out.println(decimals + " DIGITS OF e");

            long startTime = System.currentTimeMillis();
            e.eulersAprx(decimals);
            long elapsedTime = System.currentTimeMillis() - startTime;

            System.out.println(e.tempNo.toString());
            System.out.println("TIME: " + elapsedTime + " ms");

            System.out.println(e.trueE);
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }



    }
}